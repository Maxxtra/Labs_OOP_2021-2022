public class Patrat extends Dreptunghi {
    public Patrat(int latura1, double unghi1) {
        super(latura1, latura1, unghi1);
    }

    @Override
    public double arie() {
        return super.arie();
    }
}